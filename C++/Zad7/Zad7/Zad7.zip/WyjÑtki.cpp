#include "stdafx.h"
#include "Wyj�tki.h"


void licznik_rowny_0::wypisz()
{
	std::cout << str.c_str() << std::endl;
}

void mianownik_rowny_0::wypisz()
{
	std::cout << str.c_str() << std::endl;
}

void dzielenie_przez_0::wypisz()
{
	std::cout << str.c_str() << std::endl;
}

void przekroczenie_zakresu::wypisz()
{
	std::cout << str.c_str() << std::endl;
}
