#include "stdafx.h"
#include "Wyrazenie.h"


Wyrazenie::Wyrazenie()
{
}


Wyrazenie::~Wyrazenie()
{
}

